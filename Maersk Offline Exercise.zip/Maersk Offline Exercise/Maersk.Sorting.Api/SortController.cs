﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace Maersk.Sorting.Api.Controllers
{
    [ApiController]
    [Route("sort")]
    public class SortController : ControllerBase
    {
        private readonly ISortJobProcessor _sortJobProcessor;

        public SortController(ISortJobProcessor sortJobProcessor)
        {
            _sortJobProcessor = sortJobProcessor;
        }

        [HttpPost("run")]
        [Obsolete("This executes the sort job asynchronously. Use the asynchronous 'EnqueueJob' instead.")]
        public async Task<ActionResult<SortJob>> EnqueueAndRunJob(int[] values)
        {
            var pendingJob = new SortJob(
                id: Guid.NewGuid(),
                status: SortJobStatus.Pending,
                duration: null,
                input: values,
                output: null);

            var completedJob = await _sortJobProcessor.Process(pendingJob);

            return Ok(completedJob);
        }

        ////http://localhost:51435/sort/postjob  in the body pass this value [2,3,1,5,3,1,-20,2]
        [HttpPost("postjob")]
        public IActionResult EnqueueJob(int[] values)
        {
            if (values == null)
            {
                return NotFound();
            }
            var pendingJob = new SortJob(
               id: Guid.NewGuid(),
               status: SortJobStatus.Pending,
               duration: null,
               input: values,
               output: null);
            SortJobRepository.JobQueue.Enqueue(pendingJob); // to queue the job for processing
            SortJobRepository.JobList.Add(pendingJob); // to store all the jobs
            return Ok(pendingJob);
        }

        ////http://localhost:51435/sort
        [HttpGet]
        public IActionResult GetJobs()
        {
            return Ok(SortJobRepository.JobList);
        }


        ////http://localhost:51435/sort/fa21160e-e39e-4566-b0a3-699a8742fdfd
        [HttpGet("{jobId}")]
        public IActionResult GetJob(Guid jobId)
        {
            // TODO: Should return a specific job by ID.
            SortJob sortJob = SortJobRepository.JobList.Where(J => J.Id.Equals(jobId)).SingleOrDefault();
            if (sortJob != null)
            {
                return Ok(sortJob);
            }
            return NotFound();
        }
    }
}
