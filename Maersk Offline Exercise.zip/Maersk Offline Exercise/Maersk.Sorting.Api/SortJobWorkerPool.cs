﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Maersk.Sorting.Api
{
    public class SortJobWorkerPool
    {                 

        public SortJob Process(SortJob job)
        {

            try
            {
                var stopwatch = Stopwatch.StartNew();

                var output = job.Input.OrderBy(n => n).ToArray();
                Task.Delay(5000); // NOTE: This is just to simulate a more expensive operation

                var duration = stopwatch.Elapsed;

                return new SortJob(
                    id: job.Id,
                    status: SortJobStatus.Completed,
                    duration: duration,
                    input: job.Input,
                    output: output);
            }
            catch
            {
                return new SortJob(
                    id: job.Id,
                    status: SortJobStatus.Failed,
                    duration: null,
                    input: job.Input,
                    output: null);
            }
        }

        public static void Start()
        {
            SortJobWorkerPool workerpool = new SortJobWorkerPool();
            while (true)
            {
                SortJob? processedJob = null;
                if (SortJobRepository.JobQueue.TryDequeue(out processedJob))
                {
                    processedJob = workerpool.Process(processedJob);
                    SortJob sortJob = SortJobRepository.JobList.Where(J => J.Id.Equals(processedJob.Id)).SingleOrDefault();

                    sortJob.Status = processedJob.Status;
                    sortJob.Duration = processedJob.Duration;
                    sortJob.Output = processedJob.Output;

                }
                else
                {
                    Task.Delay(1000);
                }
                
            }
        }
        
    }
}
