﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Concurrent;

namespace Maersk.Sorting.Api
{
    public class SortJobRepository
    {
        public static ConcurrentQueue<SortJob> JobQueue = new ConcurrentQueue<SortJob>();
        public static ConcurrentList<SortJob> JobList = new ConcurrentList<SortJob>();
    }
}
